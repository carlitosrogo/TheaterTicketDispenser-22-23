package theater;

/**
 *
 * @author carlosrodriguezgomez
 */
public enum SeatState {
    occupied,
    free,
    notAvaible,
    selected
}
