package main;

/**
 *
 * @author carlosrodriguezgomez
 */
public enum ScreenResult{
continueInScreen,
exitScreen
}
