package main;

import java.io.FileNotFoundException;

/**
 *
 * @author carlosrodriguezgomez
 */
public class TheaterAPP {
    
    public static void main(String[] args){
        TheaterManager atm = new TheaterManager();
        atm.run();
    }
    
}
