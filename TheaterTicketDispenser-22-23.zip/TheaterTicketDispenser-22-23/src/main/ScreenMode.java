package main;

/**
 *
 * @author carlosrodriguezgomez
 */
public enum ScreenMode {
    messageMode,
    optionsMode,
    theaterMode
}
